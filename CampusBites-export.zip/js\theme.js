import { defaultTheme, storageKeys } from "./data.js";

const themeMap = {
  accentColor: "accent",
  accentDarkColor: "accentDark",
  bgColor: "bg",
  inkColor: "ink",
  mutedColor: "muted",
  leafColor: "leaf"
};

export function loadTheme() {
  const stored = JSON.parse(localStorage.getItem(storageKeys.theme) || "null");
  return stored ? { ...defaultTheme, ...stored } : { ...defaultTheme };
}

export function applyTheme(theme) {
  const root = document.documentElement;
  root.style.setProperty("--accent", theme.accent);
  root.style.setProperty("--accent-dark", theme.accentDark);
  root.style.setProperty("--bg", theme.bg);
  root.style.setProperty("--ink", theme.ink);
  root.style.setProperty("--muted", theme.muted);
  root.style.setProperty("--leaf", theme.leaf);
}

export function syncThemeControls(elements, theme) {
  Object.entries(themeMap).forEach(([id, key]) => {
    elements[id].value = theme[key];
  });
}

export function bindThemeControls(elements, onThemeChange) {
  const currentTheme = loadTheme();
  applyTheme(currentTheme);
  syncThemeControls(elements, currentTheme);

  Object.entries(themeMap).forEach(([id, key]) => {
    elements[id].addEventListener("input", (event) => {
      currentTheme[key] = event.target.value;
      applyTheme(currentTheme);
      localStorage.setItem(storageKeys.theme, JSON.stringify(currentTheme));
      onThemeChange();
    });
  });

  elements.resetTheme.addEventListener("click", () => {
    const resetTheme = { ...defaultTheme };
    applyTheme(resetTheme);
    syncThemeControls(elements, resetTheme);
    localStorage.setItem(storageKeys.theme, JSON.stringify(resetTheme));
    onThemeChange();
  });
}
