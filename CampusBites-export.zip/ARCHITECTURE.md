# Campus Bites Architecture

## Current shape

This project is currently a browser-first prototype that is organized to be backend-ready:

- `index.html`
  Main application shell and UI sections.
- `styles.css`
  Visual system, responsive layout, and CSS variable-based theming.
- `js/data.js`
  Seed campus/store data, seed meals, theme defaults, and storage keys.
- `js/state.js`
  Client state, meal enrichment, filtering, and persistence helpers.
- `js/api.js`
  Mock API boundary. The UI calls this layer instead of writing directly to storage.
- `js/render.js`
  Rendering and UI event logic.
- `js/main.js`
  Startup wiring for the app and theme controls.

## Why this matters

The `api.js` layer is the handoff point for a real backend. Right now it wraps local storage and in-memory data, but it can be replaced with real HTTP calls while keeping most of the UI intact.

## Recommended production stack

If you want this as a real deployed product, the next stack I would recommend is:

1. Frontend
   React with Vite or Next.js
2. Backend
   Node.js with Express or Next.js route handlers
3. Database
   PostgreSQL with Prisma
4. Auth
   Clerk, Supabase Auth, or Auth.js
5. Maps and stores
   Google Maps Places API or Mapbox + grocery partner APIs
6. Recipe import pipeline
   URL ingestion service, scraping worker where legally permitted, and manual review fallback

## Suggested real API endpoints

- `POST /api/recipes/import`
  Accepts social URL, source app, and campus
- `POST /api/meals`
  Creates a custom meal
- `GET /api/meals`
  Lists meals with filter params for campus, source, and max price
- `POST /api/saved/:mealId`
  Saves or unsaves a meal
- `GET /api/planner`
  Returns weekly plan
- `POST /api/planner/items`
  Adds a meal to the weekly plan
- `DELETE /api/planner/items/:itemId`
  Removes a planned meal
- `GET /api/stores/nearby?campus=...`
  Returns nearby stores and pricing context
- `GET /api/theme`
  Loads user theme tokens
- `PUT /api/theme`
  Saves user theme tokens

## Important product notes

- Real social importing needs platform policy review. For some sources, the safest route is user-submitted links plus manual or semi-automated parsing.
- Real price visibility needs live data partners or store APIs. The current store totals are estimations based on campus-specific pricing multipliers.
- Campus-specific store suggestions can later be upgraded to true geolocation and walk/transit time estimates.
