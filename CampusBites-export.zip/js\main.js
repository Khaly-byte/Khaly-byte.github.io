import { createApp } from "./render.js";
import { bindThemeControls } from "./theme.js";

const elements = {
  campusSelect: document.querySelector("#campusSelect"),
  importCampus: document.querySelector("#importCampus"),
  campusCustomWrap: document.querySelector("#campusCustomWrap"),
  campusCustom: document.querySelector("#campusCustom"),
  budgetCustomWrap: document.querySelector("#budgetCustomWrap"),
  budgetCustom: document.querySelector("#budgetCustom"),
  storeOneWrap: document.querySelector("#storeOneWrap"),
  storeOne: document.querySelector("#storeOne"),
  storeTwoWrap: document.querySelector("#storeTwoWrap"),
  storeTwo: document.querySelector("#storeTwo"),
  storeThreeWrap: document.querySelector("#storeThreeWrap"),
  storeThree: document.querySelector("#storeThree"),
  sourceSelect: document.querySelector("#sourceSelect"),
  priceRange: document.querySelector("#priceRange"),
  priceRangeLabel: document.querySelector("#priceRangeLabel"),
  mealGrid: document.querySelector("#mealGrid"),
  mealCount: document.querySelector("#mealCount"),
  detailPanel: document.querySelector("#detailPanel"),
  savedCount: document.querySelector("#savedCount"),
  budgetHeadline: document.querySelector("#budgetHeadline"),
  averageMealCost: document.querySelector("#averageMealCost"),
  averageServingCost: document.querySelector("#averageServingCost"),
  focusImport: document.querySelector("#focusImport"),
  importSection: document.querySelector("#importSection"),
  savedToggle: document.querySelector("#savedToggle"),
  cardTemplate: document.querySelector("#mealCardTemplate"),
  importForm: document.querySelector("#recipeImportForm"),
  importSource: document.querySelector("#importSource"),
  importSourceCustomWrap: document.querySelector("#importSourceCustomWrap"),
  importSourceCustom: document.querySelector("#importSourceCustom"),
  importStatus: document.querySelector("#importStatus"),
  importUrl: document.querySelector("#importUrl"),
  importTitle: document.querySelector("#importTitle"),
  importPrice: document.querySelector("#importPrice"),
  importServings: document.querySelector("#importServings"),
  importCookTime: document.querySelector("#importCookTime"),
  importCampusCustomWrap: document.querySelector("#importCampusCustomWrap"),
  importCampusCustom: document.querySelector("#importCampusCustom"),
  importBudgetCustomWrap: document.querySelector("#importBudgetCustomWrap"),
  importBudgetCustom: document.querySelector("#importBudgetCustom"),
  importStoreOneWrap: document.querySelector("#importStoreOneWrap"),
  importStoreOne: document.querySelector("#importStoreOne"),
  importStoreTwoWrap: document.querySelector("#importStoreTwoWrap"),
  importStoreTwo: document.querySelector("#importStoreTwo"),
  importStoreThreeWrap: document.querySelector("#importStoreThreeWrap"),
  importStoreThree: document.querySelector("#importStoreThree"),
  importIngredients: document.querySelector("#importIngredients"),
  importSteps: document.querySelector("#importSteps"),
  loadExampleRecipe: document.querySelector("#loadExampleRecipe"),
  addSelectedToPlan: document.querySelector("#addSelectedToPlan"),
  clearPlan: document.querySelector("#clearPlan"),
  plannerSummary: document.querySelector("#plannerSummary"),
  plannerList: document.querySelector("#plannerList"),
  storeComparison: document.querySelector("#storeComparison"),
  accentColor: document.querySelector("#accentColor"),
  accentDarkColor: document.querySelector("#accentDarkColor"),
  bgColor: document.querySelector("#bgColor"),
  inkColor: document.querySelector("#inkColor"),
  mutedColor: document.querySelector("#mutedColor"),
  leafColor: document.querySelector("#leafColor"),
  resetTheme: document.querySelector("#resetTheme")
};

const app = createApp(elements);

app.populateCampusSelects();
app.bindEvents();
bindThemeControls(elements, () => {});
app.syncCustomInputVisibility();
app.renderApp();
