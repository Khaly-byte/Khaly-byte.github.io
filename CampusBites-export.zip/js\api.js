import { addCustomMeal, getAllMeals, getMealById, persistSavedMeals, persistWeeklyPlan, state } from "./state.js";

function mockLatency(data) {
  return Promise.resolve(data);
}

export const mealsApi = {
  list() {
    return mockLatency(getAllMeals());
  },
  getById(id) {
    return mockLatency(getMealById(id));
  },
  create(meal) {
    addCustomMeal(meal);
    return mockLatency(meal);
  },
  toggleSaved(mealId) {
    if (state.savedMeals.has(mealId)) {
      state.savedMeals.delete(mealId);
    } else {
      state.savedMeals.add(mealId);
    }
    persistSavedMeals();
    return mockLatency([...state.savedMeals]);
  }
};

export const plannerApi = {
  add(mealId) {
    state.weeklyPlan.push(mealId);
    persistWeeklyPlan();
    return mockLatency([...state.weeklyPlan]);
  },
  removeAt(index) {
    state.weeklyPlan.splice(index, 1);
    persistWeeklyPlan();
    return mockLatency([...state.weeklyPlan]);
  },
  clear() {
    state.weeklyPlan = [];
    persistWeeklyPlan();
    return mockLatency([]);
  }
};
