import { baseMeals, campusData, storageKeys } from "./data.js";

const customMeals = JSON.parse(localStorage.getItem(storageKeys.customMeals) || "[]");
const customCampuses = JSON.parse(localStorage.getItem(storageKeys.customCampuses) || "{}");

export const state = {
  campus: "North Lake University",
  source: "all",
  maxPrice: 14,
  selectedMealId: null,
  savedMeals: new Set(JSON.parse(localStorage.getItem(storageKeys.savedMeals) || "[]")),
  weeklyPlan: JSON.parse(localStorage.getItem(storageKeys.weeklyPlan) || "[]")
};

export function slugify(value) {
  return value.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
}

export function getAllMeals() {
  return [...baseMeals, ...customMeals];
}

export function getMealById(id) {
  return getAllMeals().find((meal) => meal.id === id);
}

export function getCampusStores(campus) {
  const customCampus = customCampuses[campus];
  if (customCampus) {
    return customCampus.stores;
  }
  return campusData[campus].stores;
}

export function getCampusBudget(campus) {
  const customCampus = customCampuses[campus];
  if (customCampus) {
    return customCampus.weeklyBudget;
  }
  return campusData[campus].weeklyBudget;
}

export function getAvailableCampuses() {
  return [...Object.keys(campusData), ...Object.keys(customCampuses)];
}

export function addCustomCampus(name, weeklyBudget, storeNames = []) {
  const labels = [
    storeNames[0]?.trim() || "Campus market",
    storeNames[1]?.trim() || "Nearby grocery",
    storeNames[2]?.trim() || "Discount store"
  ];
  customCampuses[name] = {
    weeklyBudget,
    stores: [
      { name: labels[0], distance: "On campus", multiplier: 1, note: "Closest option for quick ingredients" },
      { name: labels[1], distance: "0.8 mi", multiplier: 0.95, note: "Best default off-campus value" },
      { name: labels[2], distance: "1.4 mi", multiplier: 0.88, note: "Cheapest estimated basket nearby" }
    ]
  };
  localStorage.setItem(storageKeys.customCampuses, JSON.stringify(customCampuses));
}

export function buildStoreOptions(meal) {
  return getCampusStores(meal.campus).map((store) => ({
    ...store,
    estimatedTotal: Number((meal.totalPrice * store.multiplier).toFixed(2))
  }));
}

export function enrichMeal(meal) {
  const stores = buildStoreOptions(meal);
  const cheapestStore = stores.reduce((best, current) => (
    current.estimatedTotal < best.estimatedTotal ? current : best
  ), stores[0]);

  return {
    ...meal,
    stores,
    cheapestStore
  };
}

export function getVisibleMeals() {
  return getAllMeals()
    .filter((meal) => {
      const matchesCampus = meal.campus === state.campus;
      const matchesSource = state.source === "all" || meal.source === state.source;
      const matchesPrice = meal.totalPrice <= state.maxPrice;
      return matchesCampus && matchesSource && matchesPrice;
    })
    .map(enrichMeal);
}

export function addCustomMeal(meal) {
  customMeals.unshift(meal);
  localStorage.setItem(storageKeys.customMeals, JSON.stringify(customMeals));
}

export function persistSavedMeals() {
  localStorage.setItem(storageKeys.savedMeals, JSON.stringify([...state.savedMeals]));
}

export function persistWeeklyPlan() {
  localStorage.setItem(storageKeys.weeklyPlan, JSON.stringify(state.weeklyPlan));
}
