export const storageKeys = {
  customMeals: "campusBitesCustomMeals",
  customCampuses: "campusBitesCustomCampuses",
  savedMeals: "campusBitesSaved",
  weeklyPlan: "campusBitesWeeklyPlan",
  theme: "campusBitesTheme"
};

export const defaultTheme = {
  bg: "#f6f0e8",
  ink: "#1d1d1d",
  muted: "#675f57",
  accent: "#d95d39",
  accentDark: "#8b2f1d",
  leaf: "#406343"
};

export const campusData = {
  "North Lake University": {
    weeklyBudget: 35,
    stores: [
      { name: "Target Express", distance: "0.4 mi", multiplier: 1, note: "Fastest all-around stop" },
      { name: "Campus Corner Market", distance: "0.2 mi", multiplier: 1.08, note: "Closest walk from dorms" },
      { name: "Fresh Market Hub", distance: "0.9 mi", multiplier: 0.94, note: "Best value on proteins" }
    ]
  },
  "City Tech College": {
    weeklyBudget: 32,
    stores: [
      { name: "Metro Grocery", distance: "0.5 mi", multiplier: 1, note: "Balanced pantry and produce prices" },
      { name: "Student Union Pantry", distance: "On campus", multiplier: 0.72, note: "Free and subsidized staples when available" },
      { name: "Value Foods", distance: "0.7 mi", multiplier: 0.93, note: "Best frozen and breakfast deals" }
    ]
  },
  "River State University": {
    weeklyBudget: 30,
    stores: [
      { name: "Campus Co-op Market", distance: "0.3 mi", multiplier: 1.03, note: "Easy between classes" },
      { name: "Green Basket", distance: "0.6 mi", multiplier: 0.91, note: "Best pantry pricing nearby" },
      { name: "Discount Mart", distance: "1.1 mi", multiplier: 0.87, note: "Worth the longer trip for bulk shopping" }
    ]
  }
};

export const baseMeals = [
  {
    id: "spicy-ramen-egg",
    title: "Spicy Ramen Egg Bowl",
    source: "TikTok",
    campus: "North Lake University",
    totalPrice: 6.85,
    servings: 2,
    cookTime: "12 min",
    tags: ["Dorm friendly", "High protein", "One pot"],
    importUrl: "https://www.tiktok.com/example/spicy-ramen-egg",
    ingredients: [
      { name: "Instant ramen", amount: "2 packs", price: 1.6 },
      { name: "Eggs", amount: "4 large", price: 1.48 },
      { name: "Frozen spinach", amount: "1 bag", price: 1.69 },
      { name: "Chili crisp", amount: "2 tbsp", price: 1.12 },
      { name: "Soy sauce", amount: "1 tbsp", price: 0.96 }
    ],
    steps: [
      "Boil the ramen and spinach in the same pot for a quick base.",
      "Soft boil or fry the eggs while the noodles cook.",
      "Stir in soy sauce and chili crisp, then top with eggs."
    ]
  },
  {
    id: "chicken-rice-burrito",
    title: "Chicken Rice Burrito Bowl",
    source: "Instagram",
    campus: "North Lake University",
    totalPrice: 11.2,
    servings: 4,
    cookTime: "20 min",
    tags: ["Meal prep", "Microwave friendly", "Budget staple"],
    importUrl: "https://www.instagram.com/example/chicken-rice-burrito",
    ingredients: [
      { name: "Microwave rice", amount: "2 pouches", price: 4.0 },
      { name: "Rotisserie chicken", amount: "1 chicken", price: 4.99 },
      { name: "Black beans", amount: "1 can", price: 1.19 },
      { name: "Salsa", amount: "1 jar", price: 1.02 }
    ],
    steps: [
      "Warm the rice and beans together with a little salsa.",
      "Pull the rotisserie chicken into small pieces.",
      "Assemble bowls and portion into containers for later meals."
    ]
  },
  {
    id: "peanut-noodles",
    title: "Cold Peanut Noodle Cup",
    source: "Facebook",
    campus: "City Tech College",
    totalPrice: 8.35,
    servings: 3,
    cookTime: "15 min",
    tags: ["No oven", "Vegetarian", "Meal prep"],
    importUrl: "https://www.facebook.com/example/peanut-noodles",
    ingredients: [
      { name: "Spaghetti", amount: "8 oz", price: 1.39 },
      { name: "Peanut butter", amount: "4 tbsp", price: 1.22 },
      { name: "Cucumber", amount: "1 whole", price: 0.99 },
      { name: "Carrots", amount: "1 bag", price: 1.49 },
      { name: "Soy sauce", amount: "2 tbsp", price: 1.1 },
      { name: "Lime", amount: "1 whole", price: 0.89 },
      { name: "Sriracha", amount: "1 tbsp", price: 1.27 }
    ],
    steps: [
      "Cook and rinse the pasta until it is cool.",
      "Whisk peanut butter, soy sauce, lime juice, and sriracha.",
      "Toss noodles with sliced vegetables and the sauce."
    ]
  },
  {
    id: "loaded-potato-skillet",
    title: "Loaded Potato Breakfast Skillet",
    source: "Instagram",
    campus: "City Tech College",
    totalPrice: 9.1,
    servings: 4,
    cookTime: "18 min",
    tags: ["Breakfast", "One pan", "Filling"],
    importUrl: "https://www.instagram.com/example/loaded-potato-skillet",
    ingredients: [
      { name: "Frozen hash browns", amount: "1 bag", price: 2.99 },
      { name: "Eggs", amount: "6 large", price: 2.22 },
      { name: "Shredded cheese", amount: "1 bag", price: 2.49 },
      { name: "Green onions", amount: "1 bunch", price: 0.99 },
      { name: "Greek yogurt", amount: "1 cup", price: 0.41 }
    ],
    steps: [
      "Crisp the hash browns in a skillet.",
      "Crack eggs on top and cover until set.",
      "Add cheese, onions, and a spoon of yogurt before serving."
    ]
  },
  {
    id: "lentil-tacos",
    title: "Lentil Taco Night",
    source: "TikTok",
    campus: "River State University",
    totalPrice: 7.4,
    servings: 4,
    cookTime: "25 min",
    tags: ["Plant based", "High fiber", "Cheap dinner"],
    importUrl: "https://www.tiktok.com/example/lentil-tacos",
    ingredients: [
      { name: "Brown lentils", amount: "1 lb", price: 1.79 },
      { name: "Taco seasoning", amount: "1 packet", price: 0.89 },
      { name: "Corn tortillas", amount: "10 count", price: 1.49 },
      { name: "Onion", amount: "1 whole", price: 0.82 },
      { name: "Tomato", amount: "2 whole", price: 1.39 },
      { name: "Cheddar cheese", amount: "1 cup", price: 1.02 }
    ],
    steps: [
      "Simmer lentils until tender, then stir in taco seasoning.",
      "Warm tortillas and prep tomato and onion toppings.",
      "Build tacos and use leftovers for lunch bowls the next day."
    ]
  },
  {
    id: "turkey-pesto-melts",
    title: "Turkey Pesto Melt Sandwiches",
    source: "Facebook",
    campus: "River State University",
    totalPrice: 10.55,
    servings: 4,
    cookTime: "14 min",
    tags: ["Quick lunch", "Protein", "Air fryer optional"],
    importUrl: "https://www.facebook.com/example/turkey-pesto-melts",
    ingredients: [
      { name: "Sandwich bread", amount: "8 slices", price: 2.1 },
      { name: "Deli turkey", amount: "8 oz", price: 3.49 },
      { name: "Mozzarella", amount: "6 slices", price: 2.19 },
      { name: "Pesto", amount: "3 tbsp", price: 1.44 },
      { name: "Tomato", amount: "1 whole", price: 1.33 }
    ],
    steps: [
      "Spread pesto on bread and layer turkey, cheese, and tomato.",
      "Toast in a pan or air fryer until the bread is crisp.",
      "Pair with fruit or soup for a fuller meal."
    ]
  }
];
