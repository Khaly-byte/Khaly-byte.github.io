import { mealsApi, plannerApi } from "./api.js";
import {
  addCustomCampus,
  enrichMeal,
  getAllMeals,
  getAvailableCampuses,
  getCampusBudget,
  getCampusStores,
  getMealById,
  getVisibleMeals,
  slugify,
  state
} from "./state.js";

function formatCurrency(value) {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD"
  }).format(value);
}

export function createApp(elements) {
  function updateOverview(meals) {
    const weeklyBudget = getCampusBudget(state.campus);
    const averageMeal = meals.length
      ? meals.reduce((sum, meal) => sum + meal.totalPrice, 0) / meals.length
      : 0;
    const averageServing = meals.length
      ? meals.reduce((sum, meal) => sum + meal.totalPrice / meal.servings, 0) / meals.length
      : 0;

    elements.budgetHeadline.textContent = formatCurrency(weeklyBudget);
    elements.averageMealCost.textContent = formatCurrency(averageMeal);
    elements.averageServingCost.textContent = formatCurrency(averageServing);
    elements.savedCount.textContent = state.savedMeals.size;
  }

  function renderStoreComparison() {
    const stores = getCampusStores(state.campus);
    const selectedMeal = getMealById(state.selectedMealId);
    const planMeals = state.weeklyPlan.map((mealId) => getMealById(mealId)).filter(Boolean);
    const comparisonMeals = selectedMeal ? [selectedMeal, ...planMeals] : planMeals;

    const cards = stores.map((store) => {
      const total = comparisonMeals.reduce((sum, meal) => sum + meal.totalPrice * store.multiplier, 0);
      return { ...store, total: Number(total.toFixed(2)) };
    }).sort((a, b) => a.total - b.total);

    elements.storeComparison.innerHTML = cards.map((store, index) => `
      <div class="comparison-card">
        <div>
          <p class="detail-label">${index === 0 ? "Best value" : "Nearby option"}</p>
          <strong>${store.name}</strong>
          <p>${store.note}</p>
        </div>
        <div>
          <span class="store-distance">${store.distance}</span>
          <strong>${formatCurrency(store.total)}</strong>
        </div>
      </div>
    `).join("");
  }

  async function toggleSaveMeal(mealId) {
    await mealsApi.toggleSaved(mealId);
    renderApp();
  }

  async function addMealToPlan(mealId) {
    await plannerApi.add(mealId);
    renderPlanner();
    renderStoreComparison();
  }

  function renderMealDetail() {
    const rawMeal = getMealById(state.selectedMealId);
    if (!rawMeal) {
      elements.detailPanel.innerHTML = '<p class="detail-empty">Choose a meal to see ingredients, prices, and where to shop nearby.</p>';
      return;
    }

    const meal = enrichMeal(rawMeal);
    const ingredientMarkup = meal.ingredients.map((ingredient) => `
      <li class="ingredient-item">
        <div>
          <strong>${ingredient.name}</strong>
          <span class="ingredient-note">${ingredient.amount}</span>
        </div>
        <strong>${formatCurrency(ingredient.price)}</strong>
      </li>
    `).join("");

    const storeMarkup = meal.stores.map((store) => `
      <li class="store-item">
        <div>
          <strong>${store.name}</strong>
          <span class="store-note">${store.note}</span>
        </div>
        <div>
          <span class="store-distance">${store.distance}</span>
          <strong>${formatCurrency(store.estimatedTotal)}</strong>
        </div>
      </li>
    `).join("");

    const stepMarkup = meal.steps.map((step, index) => `
      <li class="step-item">
        <strong>Step ${index + 1}</strong>
        <span>${step}</span>
      </li>
    `).join("");

    elements.detailPanel.innerHTML = `
      <div class="detail-heading">
        <div>
          <p class="eyebrow">${meal.source} import</p>
          <h3>${meal.title}</h3>
          <p class="meal-meta">${meal.campus} | ${meal.cookTime} | ${meal.servings} servings</p>
        </div>
        <div class="detail-price">
          <span class="detail-label">Meal total</span>
          <strong>${formatCurrency(meal.totalPrice)}</strong>
          <span>${formatCurrency(meal.totalPrice / meal.servings)} per serving</span>
        </div>
      </div>

      <div class="detail-block">
        <p class="detail-label">Best nearby store</p>
        <div class="comparison-card">
          <div>
            <strong>${meal.cheapestStore.name}</strong>
            <p>${meal.cheapestStore.note}</p>
          </div>
          <div>
            <span class="store-distance">${meal.cheapestStore.distance}</span>
            <strong>${formatCurrency(meal.cheapestStore.estimatedTotal)}</strong>
          </div>
        </div>
      </div>

      <div class="detail-block">
        <p class="detail-label">Tags</p>
        <div class="tag-row">${meal.tags.map((tag) => `<span class="tag">${tag}</span>`).join("")}</div>
      </div>

      <div class="detail-block">
        <p class="detail-label">Imported from</p>
        <p class="meal-meta">${meal.importUrl || "Imported manually inside Campus Bites"}</p>
      </div>

      <div class="detail-block">
        <p class="detail-label">Ingredient prices</p>
        <ul class="ingredient-list">${ingredientMarkup}</ul>
      </div>

      <div class="detail-block">
        <p class="detail-label">Where to shop near campus</p>
        <ul class="store-list">${storeMarkup}</ul>
      </div>

      <div class="detail-block">
        <p class="detail-label">Recipe steps</p>
        <ul class="steps-list">${stepMarkup}</ul>
      </div>

      <div class="detail-block">
        <div class="planner-actions">
          <button class="primary-button" id="detailSaveButton" type="button">${state.savedMeals.has(meal.id) ? "Saved to your list" : "Save this meal"}</button>
          <button class="secondary-button" id="detailPlanButton" type="button">Add to weekly plan</button>
        </div>
      </div>
    `;

    document.querySelector("#detailSaveButton").addEventListener("click", () => {
      toggleSaveMeal(meal.id);
    });

    document.querySelector("#detailPlanButton").addEventListener("click", () => {
      addMealToPlan(meal.id);
    });
  }

  function renderPlanner() {
    const plannedMeals = state.weeklyPlan
      .map((mealId) => getMealById(mealId))
      .filter(Boolean)
      .map(enrichMeal);
    const weeklyBudget = getCampusBudget(state.campus);
    const total = plannedMeals.reduce((sum, meal) => sum + meal.cheapestStore.estimatedTotal, 0);
    const remaining = weeklyBudget - total;

    elements.plannerSummary.innerHTML = `
      <div>
        <p class="detail-label">Planned spend</p>
        <strong>${formatCurrency(total)}</strong>
      </div>
      <div>
        <p class="detail-label">Budget left</p>
        <strong>${formatCurrency(remaining)}</strong>
      </div>
    `;

    if (!plannedMeals.length) {
      elements.plannerList.innerHTML = `
        <div class="empty-state">
          <h4>Your weekly plan is empty.</h4>
          <p>Add a meal from the browser to build out a low-cost week.</p>
        </div>
      `;
      return;
    }

    elements.plannerList.innerHTML = plannedMeals.map((meal, index) => `
      <div class="planner-item">
        <div>
          <strong>${meal.title}</strong>
          <p>${meal.cheapestStore.name} | ${meal.servings} servings | ${meal.cookTime}</p>
        </div>
        <div>
          <strong>${formatCurrency(meal.cheapestStore.estimatedTotal)}</strong>
          <button type="button" data-remove-plan="${index}">Remove</button>
        </div>
      </div>
    `).join("");

    document.querySelectorAll("[data-remove-plan]").forEach((button) => {
      button.addEventListener("click", async () => {
        const index = Number(button.getAttribute("data-remove-plan"));
        await plannerApi.removeAt(index);
        renderPlanner();
        renderStoreComparison();
      });
    });
  }

  function renderMealGrid() {
    const meals = getVisibleMeals();
    elements.mealGrid.innerHTML = "";
    elements.mealCount.textContent = `${meals.length} meal${meals.length === 1 ? "" : "s"}`;

    if (!meals.length) {
      elements.mealGrid.innerHTML = `
        <div class="empty-state">
          <h4>No meals match this filter.</h4>
          <p>Try another campus, source app, or raise the max meal price.</p>
        </div>
      `;
      elements.detailPanel.innerHTML = '<p class="detail-empty">No meal selected right now because the current filters returned no matches.</p>';
      updateOverview(meals);
      renderStoreComparison();
      return;
    }

    if (!state.selectedMealId || !meals.some((meal) => meal.id === state.selectedMealId)) {
      state.selectedMealId = meals[0].id;
    }

    meals.forEach((meal) => {
      const card = elements.cardTemplate.content.firstElementChild.cloneNode(true);
      const sourcePill = card.querySelector(".source-pill");
      const saveButton = card.querySelector(".save-button");

      sourcePill.textContent = meal.source;
      sourcePill.classList.add(meal.source.toLowerCase());
      card.querySelector(".meal-title").textContent = meal.title;
      card.querySelector(".meal-meta").textContent = `${meal.campus} | ${meal.cookTime} | ${meal.servings} servings`;
      card.querySelector(".meal-total").textContent = formatCurrency(meal.totalPrice);
      card.querySelector(".meal-serving").textContent = formatCurrency(meal.totalPrice / meal.servings);

      const tagRow = card.querySelector(".tag-row");
      meal.tags.forEach((tag) => {
        const tagNode = document.createElement("span");
        tagNode.className = "tag";
        tagNode.textContent = tag;
        tagRow.appendChild(tagNode);
      });

      saveButton.textContent = state.savedMeals.has(meal.id) ? "Saved" : "Save";
      saveButton.classList.toggle("is-saved", state.savedMeals.has(meal.id));
      card.classList.toggle("is-active", meal.id === state.selectedMealId);

      saveButton.addEventListener("click", (event) => {
        event.stopPropagation();
        toggleSaveMeal(meal.id);
      });

      card.addEventListener("click", () => {
        state.selectedMealId = meal.id;
        renderApp();
      });

      elements.mealGrid.appendChild(card);
    });

    updateOverview(meals);
    renderMealDetail();
    renderStoreComparison();
  }

  function populateCampusSelects() {
    [elements.campusSelect, elements.importCampus].forEach((select) => {
      select.innerHTML = "";
    });

    getAvailableCampuses().forEach((campus) => {
      [elements.campusSelect, elements.importCampus].forEach((select) => {
        const option = document.createElement("option");
        option.value = campus;
        option.textContent = campus;
        select.appendChild(option);
      });
    });

    [elements.campusSelect, elements.importCampus].forEach((select) => {
      const customOption = document.createElement("option");
      customOption.value = "__custom__";
      customOption.textContent = "Add my college...";
      select.appendChild(customOption);
    });

    elements.campusSelect.value = state.campus;
    elements.importCampus.value = state.campus;
  }

  function populateSourceFilterOptions() {
    const currentValue = state.source;
    const sources = [...new Set(getAllMeals().map((meal) => meal.source))].sort();
    elements.sourceSelect.innerHTML = '<option value="all">All apps</option>';

    sources.forEach((source) => {
      const option = document.createElement("option");
      option.value = source;
      option.textContent = source;
      elements.sourceSelect.appendChild(option);
    });

    elements.sourceSelect.value = sources.includes(currentValue) || currentValue === "all" ? currentValue : "all";
  }

  function setVisibility(element, visible) {
    element.classList.toggle("hidden-input", !visible);
  }

  function syncCustomInputVisibility() {
    const campusCustomSelected = elements.campusSelect.value === "__custom__";
    const importCampusCustomSelected = elements.importCampus.value === "__custom__";
    const sourceCustomSelected = elements.importSource.value === "Other";

    setVisibility(elements.campusCustomWrap, campusCustomSelected);
    setVisibility(elements.budgetCustomWrap, campusCustomSelected);
    setVisibility(elements.storeOneWrap, campusCustomSelected);
    setVisibility(elements.storeTwoWrap, campusCustomSelected);
    setVisibility(elements.storeThreeWrap, campusCustomSelected);
    setVisibility(elements.importCampusCustomWrap, importCampusCustomSelected);
    setVisibility(elements.importBudgetCustomWrap, importCampusCustomSelected);
    setVisibility(elements.importStoreOneWrap, importCampusCustomSelected);
    setVisibility(elements.importStoreTwoWrap, importCampusCustomSelected);
    setVisibility(elements.importStoreThreeWrap, importCampusCustomSelected);
    setVisibility(elements.importSourceCustomWrap, sourceCustomSelected);
  }

  function ensureCustomCampus(name, weeklyBudget, storeNames = []) {
    const trimmedName = name.trim();
    if (!trimmedName) {
      return null;
    }

    addCustomCampus(trimmedName, Number(weeklyBudget || 35), storeNames);
    populateCampusSelects();
    return trimmedName;
  }

  function loadDemoRecipe() {
    elements.importSource.value = "TikTok";
    elements.importCampus.value = state.campus;
    elements.importUrl.value = "https://www.tiktok.com/example/dorm-chili-mac";
    elements.importTitle.value = "Dorm Chili Mac";
    elements.importPrice.value = "8.75";
    elements.importServings.value = "3";
    elements.importCookTime.value = "15 min";
    elements.importIngredients.value = [
      "Elbow pasta | 8 oz | 1.49",
      "Turkey chili | 1 can | 3.29",
      "Shredded cheddar | 1 cup | 1.79",
      "Milk | 0.5 cup | 0.68",
      "Frozen corn | 1 cup | 1.50"
    ].join("\n");
    elements.importSteps.value = [
      "Boil pasta until tender.",
      "Warm chili with milk and corn.",
      "Stir in pasta and top with cheddar."
    ].join("\n");
    elements.importStatus.textContent = "Demo recipe loaded";
  }

  async function handleImportSubmit(event) {
    event.preventDefault();

    const ingredients = elements.importIngredients.value
      .split("\n")
      .map((line) => line.trim())
      .filter(Boolean)
      .map((line) => {
        const [name, amount, price] = line.split("|").map((part) => part.trim());
        return { name: name || "Ingredient", amount: amount || "1 unit", price: Number(price || 0) };
      });

    const steps = elements.importSteps.value.split("\n").map((line) => line.trim()).filter(Boolean);
    const title = elements.importTitle.value.trim();
    const resolvedSource = elements.importSource.value === "Other"
      ? elements.importSourceCustom.value.trim()
      : elements.importSource.value;
    const resolvedCampus = elements.importCampus.value === "__custom__"
      ? ensureCustomCampus(
          elements.importCampusCustom.value,
          elements.importBudgetCustom.value,
          [elements.importStoreOne.value, elements.importStoreTwo.value, elements.importStoreThree.value]
        )
      : elements.importCampus.value;

    if (!title || !ingredients.length || !steps.length || !resolvedSource || !resolvedCampus) {
      elements.importStatus.textContent = "Add a title, source, campus, ingredients, and steps";
      return;
    }

    const customMeal = {
      id: `custom-${slugify(title)}-${Date.now()}`,
      title,
      source: resolvedSource,
      campus: resolvedCampus,
      totalPrice: Number(elements.importPrice.value || 0),
      servings: Number(elements.importServings.value || 1),
      cookTime: elements.importCookTime.value.trim() || "15 min",
      tags: ["Student imported", "Budget tracked", "Custom meal"],
      importUrl: elements.importUrl.value.trim(),
      ingredients,
      steps
    };

    await mealsApi.create(customMeal);
    populateSourceFilterOptions();
    state.campus = customMeal.campus;
    state.selectedMealId = customMeal.id;
    elements.campusSelect.value = state.campus;
    elements.importCampus.value = state.campus;
    elements.importForm.reset();
    elements.importStatus.textContent = "Recipe imported into your meal board";
    syncCustomInputVisibility();
    renderApp();
  }

  async function showSavedMeals() {
    const savedMeals = (await mealsApi.list()).filter((meal) => state.savedMeals.has(meal.id)).map(enrichMeal);

    if (!savedMeals.length) {
      elements.detailPanel.innerHTML = `
        <p class="detail-empty">You have not saved any meals yet. Try saving a meal card to build your budget meal list.</p>
      `;
      return;
    }

    elements.detailPanel.innerHTML = `
      <div class="detail-heading">
        <div>
          <p class="eyebrow">Saved list</p>
          <h3>Your budget meal board</h3>
          <p class="meal-meta">${savedMeals.length} saved recipe${savedMeals.length === 1 ? "" : "s"}</p>
        </div>
      </div>
      <div class="detail-block">
        <p class="detail-label">Saved meals</p>
        <ul class="store-list">${savedMeals.map((meal) => `
          <li class="store-item">
            <div>
              <strong>${meal.title}</strong>
              <span class="store-note">${meal.source} | ${meal.campus}</span>
            </div>
            <div>
              <span class="store-distance">${meal.cheapestStore.name}</span>
              <strong>${formatCurrency(meal.cheapestStore.estimatedTotal)}</strong>
            </div>
          </li>
        `).join("")}</ul>
      </div>
    `;
  }

  function bindEvents() {
    elements.campusSelect.addEventListener("change", (event) => {
      if (event.target.value === "__custom__") {
        syncCustomInputVisibility();
        return;
      }
      state.campus = event.target.value;
      elements.importCampus.value = state.campus;
      syncCustomInputVisibility();
      renderApp();
    });

    elements.sourceSelect.addEventListener("change", (event) => {
      state.source = event.target.value;
      renderApp();
    });

    elements.priceRange.addEventListener("input", (event) => {
      state.maxPrice = Number(event.target.value);
      elements.priceRangeLabel.textContent = formatCurrency(state.maxPrice);
      renderApp();
    });

    elements.focusImport.addEventListener("click", () => {
      elements.importSection.scrollIntoView({ behavior: "smooth", block: "start" });
    });

    elements.importCampus.addEventListener("change", syncCustomInputVisibility);
    elements.importSource.addEventListener("change", syncCustomInputVisibility);

    elements.campusCustom.addEventListener("change", () => {
      const campusName = ensureCustomCampus(
        elements.campusCustom.value,
        elements.budgetCustom.value,
        [elements.storeOne.value, elements.storeTwo.value, elements.storeThree.value]
      );
      if (!campusName) {
        return;
      }
      state.campus = campusName;
      elements.campusSelect.value = campusName;
      elements.importCampus.value = campusName;
      syncCustomInputVisibility();
      renderApp();
    });

    elements.budgetCustom.addEventListener("change", () => {
      if (elements.campusSelect.value === "__custom__") {
        const campusName = ensureCustomCampus(
          elements.campusCustom.value,
          elements.budgetCustom.value,
          [elements.storeOne.value, elements.storeTwo.value, elements.storeThree.value]
        );
        if (campusName) {
          state.campus = campusName;
          elements.campusSelect.value = campusName;
          elements.importCampus.value = campusName;
          syncCustomInputVisibility();
          renderApp();
        }
      }
    });

    [elements.storeOne, elements.storeTwo, elements.storeThree].forEach((input) => {
      input.addEventListener("change", () => {
        if (elements.campusSelect.value === "__custom__") {
          const campusName = ensureCustomCampus(
            elements.campusCustom.value,
            elements.budgetCustom.value,
            [elements.storeOne.value, elements.storeTwo.value, elements.storeThree.value]
          );
          if (campusName) {
            state.campus = campusName;
            elements.campusSelect.value = campusName;
            elements.importCampus.value = campusName;
            syncCustomInputVisibility();
            renderApp();
          }
        }
      });
    });

    elements.savedToggle.addEventListener("click", showSavedMeals);
    elements.loadExampleRecipe.addEventListener("click", loadDemoRecipe);
    elements.importForm.addEventListener("submit", handleImportSubmit);
    elements.addSelectedToPlan.addEventListener("click", () => {
      if (state.selectedMealId) {
        addMealToPlan(state.selectedMealId);
      }
    });
    elements.clearPlan.addEventListener("click", async () => {
      await plannerApi.clear();
      renderPlanner();
      renderStoreComparison();
    });
  }

  function renderApp() {
    populateSourceFilterOptions();
    renderMealGrid();
    renderPlanner();
  }

  return {
    bindEvents,
    populateCampusSelects,
    syncCustomInputVisibility,
    renderApp
  };
}
